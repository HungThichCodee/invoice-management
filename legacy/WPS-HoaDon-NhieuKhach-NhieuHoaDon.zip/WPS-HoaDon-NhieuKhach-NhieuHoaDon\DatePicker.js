/* Lịch dùng chung trong task pane WPS; không dùng input date của trình duyệt. */
(function (root) {
'use strict';
const months = ['Tháng 1','Tháng 2','Tháng 3','Tháng 4','Tháng 5','Tháng 6',
  'Tháng 7','Tháng 8','Tháng 9','Tháng 10','Tháng 11','Tháng 12'];
let active = null;
const pad = n => String(n).padStart(2, '0');
const iso = d => d ? `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}` : '';
const vn = d => d ? `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()}` : '';
function parse(value) {
  const s = String(value || '').trim();
  let match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
  if (match) {
    const d = new Date(+match[3], +match[2]-1, +match[1]);
    return d.getFullYear() === +match[3] && d.getMonth() === +match[2]-1 && d.getDate() === +match[1] ? d : null;
  }
  match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s);
  if (match) {
    const d = new Date(+match[1], +match[2]-1, +match[3]);
    return d.getFullYear() === +match[1] && d.getMonth() === +match[2]-1 && d.getDate() === +match[3] ? d : null;
  }
  return null;
}
function bounds(a) {
  const min = parse(a.options.getMin && a.options.getMin());
  const max = parse(a.options.getMax && a.options.getMax());
  return {min: min && iso(min), max: max && iso(max)};
}
function allowed(a, d) {
  const value = iso(d), b = bounds(a);
  return (!b.min || value >= b.min) && (!b.max || value <= b.max);
}
function close() {
  if (!active) return;
  active.popup.remove();
  active.input.setAttribute('aria-expanded', 'false');
  active = null;
}
function choose(a, d) {
  if (!allowed(a, d)) return;
  a.input.value = vn(d);
  a.input.dispatchEvent(new Event('input', {bubbles:true}));
  a.input.dispatchEvent(new Event('change', {bubbles:true}));
  close();
  a.input.focus();
}
function el(tag, className, label, parent) {
  const e = document.createElement(tag);
  if (className) e.className = className;
  if (label != null) e.textContent = label;
  parent.appendChild(e);
  return e;
}
function button(parent, label, fn, cls) {
  const b = el('button', cls || '', label, parent);
  b.type = 'button';
  b.onclick = fn;
  return b;
}
function position(a) {
  const p = a.popup, box = a.input.getBoundingClientRect();
  const width = Math.min(320, window.innerWidth - 16);
  p.style.width = width + 'px';
  p.style.left = Math.max(8, Math.min(box.left, window.innerWidth-width-8)) + 'px';
  p.style.maxHeight = Math.max(160, window.innerHeight-16) + 'px';
  const height = p.getBoundingClientRect().height;
  p.style.top = (window.innerHeight-box.bottom < height+8 && box.top > window.innerHeight-box.bottom
    ? Math.max(8, box.top-height-5) : Math.min(box.bottom+5, window.innerHeight-height-8)) + 'px';
}
function render(a) {
  const p = a.popup;
  p.textContent = '';
  const head = el('div','dp-head',null,p);
  button(head,'‹',()=>{ if(a.mode==='years') a.yearBase-=12;
    else if(a.mode==='months') a.year--; else a.visible = new Date(a.visible.getFullYear(),a.visible.getMonth()-1,1);
    render(a); },'dp-nav');
  const caption = a.mode==='days' ? `${months[a.visible.getMonth()]}, ${a.visible.getFullYear()}`
    : a.mode==='months' ? String(a.year) : `${a.yearBase}–${a.yearBase+11}`;
  button(head,caption,()=>{ a.mode = a.mode==='days'?'months':'years';
    a.year = a.visible.getFullYear();a.yearBase=Math.floor(a.year/12)*12;render(a); },'dp-title');
  button(head,'›',()=>{ if(a.mode==='years') a.yearBase+=12;
    else if(a.mode==='months') a.year++; else a.visible = new Date(a.visible.getFullYear(),a.visible.getMonth()+1,1);
    render(a); },'dp-nav');
  const grid = el('div','dp-grid'+(a.mode==='days'?'':' dp-pick'),null,p);
  if(a.mode==='years') {
    for(let year=a.yearBase;year<a.yearBase+12;year++) button(grid,String(year),()=>{a.year=year;a.mode='months';render(a);});
  } else if(a.mode==='months') {
    for(let n=0;n<12;n++) button(grid,months[n],()=>{a.visible=new Date(a.year,n,1);a.cursor=new Date(a.year,n,1);a.mode='days';render(a);});
  } else {
    ['T2','T3','T4','T5','T6','T7','CN'].forEach(day=>el('span','dp-week',day,grid));
    const y=a.visible.getFullYear(),m=a.visible.getMonth();
    const offset=(new Date(y,m,1).getDay()+6)%7;
    for(let x=0;x<offset;x++) el('span','',null,grid);
    const today=iso(new Date()), selected=iso(parse(a.input.value));
    for(let day=1;day<=new Date(y,m+1,0).getDate();day++) {
      const d=new Date(y,m,day), key=iso(d);
      const b=button(grid,String(day),()=>choose(a,d),'dp-day'+(key===today?' dp-today':'')+(key===selected?' dp-selected':''));
      b.disabled=!allowed(a,d);
      if(key===selected) b.setAttribute('aria-current','date');
      b.setAttribute('aria-label',vn(d));
    }
  }
  const foot=el('div','dp-foot',null,p);
  button(foot,'Hôm nay',()=>choose(a,new Date())).disabled=!allowed(a,new Date());
  if(!a.options.required) button(foot,'Xóa',()=>{
    a.input.value='';a.input.dispatchEvent(new Event('input',{bubbles:true}));
    a.input.dispatchEvent(new Event('change',{bubbles:true}));close();a.input.focus();
  });
  position(a);
}
function open(input, options) {
  if(active && active.input===input) return;
  close();
  const chosen=parse(input.value), today=new Date();
  const a={input,options,popup:document.createElement('div'),visible:new Date((chosen||today).getFullYear(),(chosen||today).getMonth(),1),
    cursor:chosen||today,mode:'days',year:(chosen||today).getFullYear(),yearBase:Math.floor((chosen||today).getFullYear()/12)*12};
  a.popup.className='dp-popup';a.popup.setAttribute('role','dialog');a.popup.setAttribute('aria-label','Chọn ngày');
  (input.closest('dialog')||document.body).appendChild(a.popup);
  active=a;input.setAttribute('aria-expanded','true');render(a);
}
function move(a, days, months) {
  const base=a.cursor;
  const target=new Date(base.getFullYear(),base.getMonth()+months,1);
  let d = months ? new Date(target.getFullYear(),target.getMonth(),
    Math.min(base.getDate(),new Date(target.getFullYear(),target.getMonth()+1,0).getDate()))
    : new Date(base.getFullYear(),base.getMonth(),base.getDate()+days);
  if(!allowed(a,d)) {
    const b=bounds(a);
    d=parse(days<0||months<0?b.min:b.max);
    if(!d || !allowed(a,d)) return;
  }
  a.cursor=d;a.visible=new Date(d.getFullYear(),d.getMonth(),1);a.mode='days';render(a);
  const focused=Array.from(a.popup.querySelectorAll('.dp-day')).find(b=>b.getAttribute('aria-label')===vn(d));
  if(focused) focused.focus();
}
function attach(input, options) {
  if(typeof input==='string') input=document.querySelector(input);
  if(!input) return;
  if(input._invoiceDatePicker) return;
  options=options||{};
  options.required = options.required == null ? input.required : !!options.required;
  input._invoiceDatePicker=options;
  input.readOnly=true;input.setAttribute('aria-haspopup','dialog');input.setAttribute('aria-expanded','false');
  input.classList.add('dp-input');
  const field=document.createElement('span');field.className='dp-field';
  input.parentNode.insertBefore(field,input);field.appendChild(input);
  const icon=el('span','dp-icon','📅',field);
  icon.setAttribute('aria-hidden','true');
  input.addEventListener('click',()=>open(input,options));
  input.addEventListener('keydown',e=>{
    if(e.key==='Enter'||e.key===' '||e.key==='ArrowDown') {e.preventDefault();open(input,options);}
  });
}
document.addEventListener('pointerdown',e=>{
  if(active && !active.popup.contains(e.target) && e.target!==active.input) close();
});
document.addEventListener('keydown',e=>{
  if(!active) return;
  if(e.key==='Escape') {e.preventDefault();e.stopPropagation();close();return;}
  const a=active;
  const delta={ArrowLeft:-1,ArrowRight:1,ArrowUp:-7,ArrowDown:7}[e.key];
  if(delta) {e.preventDefault();move(a,delta,0);}
  else if(e.key==='PageUp'||e.key==='PageDown') {e.preventDefault();move(a,0,e.key==='PageUp'?-1:1);}
  else if(e.key==='Enter' && a.mode==='days' && (e.target===a.input || e.target.classList.contains('dp-day'))) {
    e.preventDefault();e.stopPropagation();choose(a,a.cursor);
  }
},true);
window.addEventListener('resize',()=>{if(active) position(active);});
window.addEventListener('scroll',()=>{if(active) position(active);},true);
root.InvoiceDatePicker={attach,close,parse,iso};
})(window);
