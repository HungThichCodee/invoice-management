// Local development server without third-party or native Node modules.
// Listens only on this computer. The workbook remains in WPS, not in this server.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const files = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/main.js': ['main.js', 'text/javascript; charset=utf-8'],
  '/ribbon.xml': ['ribbon.xml', 'application/xml; charset=utf-8'],
  '/App.html': ['App.html', 'text/html; charset=utf-8'],
  '/Store.js': ['Store.js', 'text/javascript; charset=utf-8'],
  '/View.js': ['View.js', 'text/javascript; charset=utf-8'],
  '/DatePicker.js': ['DatePicker.js', 'text/javascript; charset=utf-8'],
  '/Report.js': ['Report.js', 'text/javascript; charset=utf-8'],
};
const port = 38931;
http.createServer((request, response) => {
  const route = new URL(request.url, `http://127.0.0.1:${port}`).pathname;
  const entry = files[route];
  if (!entry) {
    response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end('Not found');
    return;
  }
  fs.readFile(path.join(__dirname, entry[0]), (error, data) => {
    if (error) {
      response.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end('Cannot read add-in file');
      return;
    }
    response.writeHead(200, { 'Content-Type': entry[1], 'Cache-Control': 'no-store' });
    response.end(data);
  });
}).listen(port, '127.0.0.1', () => {
  console.log(`WPS add-in: http://127.0.0.1:${port}/`);
});
