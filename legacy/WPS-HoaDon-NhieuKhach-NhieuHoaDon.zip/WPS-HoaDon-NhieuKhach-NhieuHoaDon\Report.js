/* Tính toán thuần từ state; không truy cập DOM hoặc workbook. */
(function (root) {
'use strict';
function keyOf(invoice) {
  return JSON.stringify([String(invoice.customer || '').trim().toLowerCase(), String(invoice.phone || '').trim()]);
}
function groupCustomers(state) {
  const groups=new Map();
  for(const invoice of state.invoices || []) {
    const key=keyOf(invoice);
    if(!groups.has(key)) groups.set(key,{key,customer:invoice.customer,phone:invoice.phone || '',
      total:0,paid:0,balance:0,invoiceCount:0,debtCount:0});
    const g=groups.get(key);
    g.total+=Number(invoice.total)||0;g.paid+=Number(invoice.paid)||0;
    g.balance+=Number(invoice.balance)||0;g.invoiceCount++;
    if(invoice.balance>0) g.debtCount++;
  }
  return Array.from(groups.values()).sort((a,b)=>b.balance-a.balance ||
    String(a.customer).localeCompare(String(b.customer),'vi'));
}
function customerInvoices(state,key,fromISO,toISO) {
  return (state.invoices || []).filter(i=>keyOf(i)===key &&
    (!fromISO || i.date>=fromISO) && (!toISO || i.date<=toISO));
}
function statusOf(invoice,today) {
  if(invoice.balance===0) return {label:'Đã thanh toán',className:'paid',overdue:false,daysLate:0};
  if(invoice.due && invoice.due<today) {
    const daysLate=Math.round((Date.parse(today)-Date.parse(invoice.due))/86400000);
    return {label:'Quá hạn '+daysLate+' ngày',className:'late',overdue:true,daysLate};
  }
  if(invoice.paid>0) return {label:'Trả một phần',className:'part',overdue:false,daysLate:0};
  return {label:'Còn nợ',className:'owe',overdue:false,daysLate:0};
}
function customerSummary(state,key,fromISO,toISO) {
  const invoices=customerInvoices(state,key,fromISO,toISO);
  const total=invoices.reduce((v,i)=>v+(Number(i.total)||0),0);
  const paid=invoices.reduce((v,i)=>v+(Number(i.paid)||0),0);
  const balance=invoices.reduce((v,i)=>v+(Number(i.balance)||0),0);
  const all=customerInvoices(state,key);
  return {total,paid,balance,debtCount:invoices.filter(i=>i.balance>0).length,
    overdueCount:invoices.filter(i=>statusOf(i,state.today).overdue).length,
    lifetimeDebt:all.reduce((v,i)=>v+(Number(i.balance)||0),0),invoiceCount:invoices.length};
}
const amount=v=>Number(v)||0;
const rate=(collected,revenue)=>revenue?collected/revenue*100:0;
const change=(current,previous)=>previous?(current-previous)/previous*100:0;
function periodRow(state,start,end,previousRevenue) {
  const invoices=(state.invoices||[]).filter(i=>i.date>=start&&i.date<=end);
  const revenue=invoices.reduce((sum,i)=>sum+amount(i.total),0);
  const collected=(state.payments||[]).filter(p=>p.date>=start&&p.date<=end)
    .reduce((sum,p)=>sum+amount(p.amount),0);
  const closingRevenue=(state.invoices||[]).filter(i=>i.date<=end)
    .reduce((sum,i)=>sum+amount(i.total),0);
  const closingCollected=(state.payments||[]).filter(p=>p.date<=end)
    .reduce((sum,p)=>sum+amount(p.amount),0);
  return {invoiceCount:invoices.length,revenue,collected,closingDebt:closingRevenue-closingCollected,
    collectRate:rate(collected,revenue),prevChangePct:change(revenue,previousRevenue)};
}
function monthlyReport(state,year) {
  const y=Number(year),rows=[];
  for(let m=1;m<=12;m++) {
    const start=`${y}-${String(m).padStart(2,'0')}-01`;
    const end=`${y}-${String(m).padStart(2,'0')}-31`;
    const previous=rows.length?rows[rows.length-1].revenue:
      (state.invoices||[]).filter(i=>i.date.slice(0,7)===`${y-1}-12`)
        .reduce((sum,i)=>sum+amount(i.total),0);
    rows.push({month:m,...periodRow(state,start,end,previous)});
  }
  return rows;
}
function yearlyReport(state) {
  const current=Number(String(state.today||'').slice(0,4))||new Date().getFullYear();
  const dates=[...(state.invoices||[]).map(i=>i.date),...(state.payments||[]).map(p=>p.date)];
  const years=dates.map(d=>Number(String(d).slice(0,4))).filter(Number.isFinite);
  const first=Math.min(current,...years),rows=[];
  for(let y=first;y<=current;y++) {
    const previous=rows.length?rows[rows.length-1].revenue:0;
    rows.push({year:y,...periodRow(state,`${y}-01-01`,`${y}-12-31`,previous)});
  }
  return rows;
}
function topDebtors(state,uptoISO,n=5) {
  const groups=new Map(),invoices=(state.invoices||[]).filter(i=>!uptoISO||i.date<=uptoISO);
  const paid=new Map();
  for(const p of state.payments||[]) if(!uptoISO||p.date<=uptoISO)
    paid.set(p.invoice,(paid.get(p.invoice)||0)+amount(p.amount));
  for(const i of invoices) {
    const key=keyOf(i);
    if(!groups.has(key)) groups.set(key,{key,customer:i.customer,phone:i.phone||'',balance:0,invoiceCount:0});
    const g=groups.get(key);
    g.balance+=amount(i.total)-(paid.get(i.id)||0);g.invoiceCount++;
  }
  return Array.from(groups.values()).filter(g=>g.balance>0)
    .sort((a,b)=>b.balance-a.balance||String(a.customer).localeCompare(String(b.customer),'vi'))
    .slice(0,Math.max(0,Number(n)||0));
}
const api={groupCustomers,customerInvoices,customerSummary,statusOf,monthlyReport,yearlyReport,topDebtors};
root.InvoiceReport=api;
if(typeof module!=='undefined') module.exports=api;
})(typeof window!=='undefined'?window:globalThis);
