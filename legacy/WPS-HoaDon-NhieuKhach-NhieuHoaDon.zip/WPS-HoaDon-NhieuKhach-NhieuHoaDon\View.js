/* Workbook presentation and local exports for WPS Sheets. */
(function (root) {
'use strict';
const OUT = 'G:\\Xe_Nang\\du-lieu\\';
const C = {
  navy: 0x503018, teal: 0x706219, white: 0xffffff,
  pale: 0xf8f4ed, stripe: 0xfaf7f3, green: 0xd7e9db,
  amber: 0xc2e8ff, red: 0xd6dcff, ink: 0x46321f
}; // WPS/Excel color values are BGR.
const fmt = n => Number(n).toLocaleString('vi-VN');
const vn = d => /^\d{4}-\d{2}-\d{2}$/.test(String(d || '')) ? `${d.slice(8,10)}/${d.slice(5,7)}/${d.slice(0,4)}` : String(d || '—');
function find(wb, name) {
  for (let n = 1; n <= wb.Worksheets.Count; n++) {
    const s = wb.Worksheets.Item(n);
    if (s.Name === name) return s;
  }
  return null;
}
function put(s, row, col, v) { s.Cells.Item(row, col).Value2 = v; }
function font(range, size, color, bold) {
  range.Font.Name = 'Arial';
  range.Font.Size = size;
  range.Font.Color = color;
  range.Font.Bold = bold;
}
function header(s, last) {
  const r = s.Range(`A1:${last}1`);
  r.Interior.Color = C.navy;
  font(r, 11, C.white, true);
  r.WrapText = true;
  s.Rows.Item(1).RowHeight = 42;
}
function widths(s, values) {
  values.forEach((v, i) => s.Range(`${String.fromCharCode(65+i)}:${String.fromCharCode(65+i)}`).ColumnWidth = v);
}
function fitRows(s, name, count) {
  const invoice=name==='FM_HoaDon';
  const columns=invoice?[1,3,5,8]:[1,2,6];
  for(let row=2;row<=count+1;row++) {
    let lines=1;
    for(const col of columns) {
      try {
        const value=String(s.Cells.Item(row,col).Value2||'');
        const width=Number(s.Columns.Item(col).ColumnWidth)||20;
        // Wider safety margin for Arial and Vietnamese text; never change values.
        lines=Math.max(lines,Math.ceil(Array.from(value).length/Math.max(8,width-4)));
      } catch (_) { /* Row stays at a readable minimum. */ }
    }
    try {s.Rows.Item(row).RowHeight=Math.min(360,Math.max(34,lines*16+10));}
    catch (_) { /* Older WPS builds may omit RowHeight. */ }
  }
}
function formatTable(s, name, count) {
  const invoice = name === 'FM_HoaDon';
  header(s, invoice ? 'H' : 'F');
  s.Range(invoice ? 'I:J' : 'G:G').EntireColumn.Hidden = true;
  try {
    s.Range(invoice ? 'B:B' : 'C:C').NumberFormat = 'dd/mm/yyyy';
    if (invoice) s.Range('F:F').NumberFormat = 'dd/mm/yyyy';
    if (invoice) s.Range('D:D').NumberFormat = '@';
  } catch (_) { /* Keep data accessible on versions without these formats. */ }
  if (!count) return;
  const end = count+1, last=invoice?'H':'F';
  const data=s.Range(`A2:${last}${end}`);
  font(data,10,C.ink,false);
  data.WrapText=true;
  try { data.RowHeight=34; } catch (_) { /* Some WPS builds omit Range.RowHeight. */ }
  try { data.Borders.LineStyle=1;data.Borders.Color=0xe5e5e5; }
  catch (_) { /* Thin gray borders are optional on older WPS builds. */ }
  const money=s.Range(`${invoice?'G':'D'}2:${invoice?'G':'D'}${end}`);
  money.NumberFormat='#,##0 "đ"';money.Font.Bold=true;money.Font.Color=C.teal;
  for(let row=2;row<=end;row+=2) s.Range(`A${row}:${last}${row}`).Interior.Color=C.stripe;
  for(let row=3;row<=end;row+=2) s.Range(`A${row}:${last}${row}`).Interior.Color=C.white;
}
function autoWidths(s,name,count) {
  const invoice=name==='FM_HoaDon';
  const fallback=invoice?[34,17,25,18,34,18,20,30]:[34,34,17,20,22,36];
  const minimum=invoice?[30,16,22,16,24,16,18,22]:[30,30,16,18,18,22];
  const heads=invoice?['Mã HĐ','Ngày','Khách hàng','Điện thoại','Địa chỉ / đơn vị','Hạn trả','Tổng tiền','Ghi chú']
    :['Mã phiếu','Mã HĐ','Ngày thu','Số tiền','Phương thức','Ghi chú'];
  for(let n=1;n<=fallback.length;n++) {
    const col=String.fromCharCode(64+n), limit=(invoice&&(n===5||n===8)||!invoice&&n===6)?40:45;
    const range=s.Range(`${col}:${col}`);
    let width;
    try {
      s.Columns.Item(n).AutoFit();
      width=Number(s.Columns.Item(n).ColumnWidth);
      if(!Number.isFinite(width)||width<=0) throw Error('AutoFit không trả về độ rộng.');
    } catch (_) {
      try {
        let longest=Array.from(heads[n-1]).length;
        for(let row=2;row<=count+1;row++) {
          const value=s.Cells.Item(row,n).Value2;
          const str=value==null?'':String(value);
          longest=Math.max(longest,Array.from(str).length);
          if(longest>=limit) break;
        }
        width=Math.ceil(longest*1.15+3);
      } catch (_) { width=fallback[n-1]; }
    }
    try {range.ColumnWidth=Math.max(minimum[n-1],Math.min(limit,width));}
    catch (_) {try {range.ColumnWidth=fallback[n-1];}catch (__) { /* Keep the current width. */ }}
    if(limit===40) try {range.WrapText=true;} catch (_) { /* Keep readable values where supported. */ }
  }
}
function formatAll(wb,state) {
  let rows=0,sheets=0;
  for(const [name,count] of [['FM_HoaDon',state.invoices.length],['FM_ThuTien',state.payments.length]]) {
    const s=find(wb,name);
    if(!s) continue;
    formatTable(s,name,count);
    autoWidths(s,name,count);
    fitRows(s,name,count);
    rows+=count;sheets++;
  }
  return {rows,sheets};
}
function refreshDashboard(wb, state) {
  let s = find(wb, 'FM_TongQuan');
  if (s && String(s.Cells.Item(1,1).Value2 || '') !== 'TỔNG QUAN HÓA ĐƠN & CÔNG NỢ') {
    throw Error('Tab FM_TongQuan đã tồn tại với nội dung khác. Không ghi đè tab này.');
  }
  if (!s) { s = wb.Worksheets.Add(); s.Name = 'FM_TongQuan'; }
  let previous=10;
  try {previous=Number(s.Range('A1048576').End(-4162).Row)||10;}
  catch (_) {previous=Math.min(50000,Number(s.UsedRange.Row||1)+Number(s.UsedRange.Rows.Count||1));}
  const end=Math.max(10,previous,state.invoices.length+8);
  s.Range(`A1:H${end}`).ClearContents();
  put(s, 1, 1, 'TỔNG QUAN HÓA ĐƠN & CÔNG NỢ');
  put(s, 2, 1, 'Dữ liệu từ hóa đơn và phiếu thu trong tệp WPS này');
  const all = state.invoices;
  const sales = all.reduce((x, i) => x + i.total, 0);
  const paid = all.reduce((x, i) => x + i.paid, 0);
  [['TỔNG TIỀN HÀNG', sales], ['ĐÃ THU', paid], ['CÒN PHẢI THU', sales-paid]].forEach(([label, value], n) => {
    put(s, 4, 1 + n*2, label);
    put(s, 5, 1 + n*2, value);
    const box = s.Range(`${String.fromCharCode(65+n*2)}4:${String.fromCharCode(65+n*2)}5`);
    box.Interior.Color = n === 2 ? C.amber : C.pale;
    font(box, 12, C.navy, true);
    s.Cells.Item(5,1+n*2).NumberFormat = '#,##0 "đ"';
  });
  ['Mã hóa đơn','Ngày lập','Khách hàng','Tổng tiền','Đã thu','Còn nợ','Trạng thái','Hạn thanh toán'].forEach((v,n) => put(s,8,n+1,v));
  const heading = s.Range('A8:H8');
  heading.Interior.Color = C.navy;
  font(heading, 11, C.white, true);
  s.Rows.Item(8).RowHeight = 38;
  widths(s,[29,17,30,20,20,20,21,20]);
  all.slice().reverse().forEach((i,n) => {
    const row = 9+n;
    const status = i.balance === 0 ? 'Đã thanh toán' : i.due && i.due < state.today ? 'Quá hạn' : 'Còn nợ';
    [i.id,vn(i.date),i.customer,i.total,i.paid,i.balance,status,vn(i.due)].forEach((v,j)=>put(s,row,j+1,v));
    const range=s.Range(`A${row}:H${row}`);
    range.Interior.Color=n%2?C.white:C.stripe;
    font(range,10,C.ink,false);
    s.Rows.Item(row).RowHeight=29;
    s.Range(`D${row}:F${row}`).NumberFormat='#,##0 "đ"';
    const marker=s.Cells.Item(row,7);
    marker.Interior.Color=status==='Quá hạn'?C.red:status==='Đã thanh toán'?C.green:C.amber;
    marker.Font.Bold=true;
  });
  s.Range('A1:H1').Interior.Color=C.navy;
  font(s.Range('A1:H1'),16,C.white,true);
  s.Rows.Item(1).RowHeight=44;
  font(s.Range('A2:H2'),10,C.teal,false);
  s.Rows.Item(2).RowHeight=28;
}
function formatAndRefresh(wb, state) {
  // Formatting is best effort; transaction data is never changed on a style error.
  for (const name of ['FM_HoaDon','FM_ThuTien']) {
    const s=find(wb,name);
    if (s) {
      try {const count=name==='FM_HoaDon'?state.invoices.length:state.payments.length;
        formatTable(s,name,count);fitRows(s,name,count);}
      catch (e) { /* Older WPS builds can omit formatting properties. */ }
    }
  }
  let dashboardError;
  try {refreshDashboard(wb,state);} catch(e) {dashboardError=e;}
  // FM_BanIn is a generated page. Keep its displayed invoice current after a receipt or edit.
  let printError;
  try {syncPrintSheet(wb,state);} catch(e) {printError=e;}
  if(dashboardError||printError)throw Error([dashboardError,printError].filter(Boolean).map(e=>e.message||String(e)).join('; '));
}
function syncPrintSheet(wb,state) {
  const s=find(wb,'FM_BanIn');
  if(!s||String(s.Cells.Item(1,1).Value2||'')!=='HÓA ĐƠN BÁN LẺ')return;
  const id=String(s.Cells.Item(3,2).Value2||'');
  if(!id)return;
  const invoice=state.invoices.find(i=>i.id===id);
  if(invoice){printSheet(wb,invoice);return;}
  // A deleted invoice must never remain as a seemingly valid printed bill.
  const end=Math.max(25,Number(s.UsedRange.Row||1)+Number(s.UsedRange.Rows.Count||1));
  s.Range(`A1:F${end}`).ClearContents();
  put(s,1,1,'HÓA ĐƠN BÁN LẺ');put(s,3,1,'Hóa đơn đã xóa khỏi dữ liệu.');
}
function printSheet(wb, invoice) {
  let s=find(wb,'FM_BanIn');
  if (s && String(s.Cells.Item(1,1).Value2 || '') !== 'HÓA ĐƠN BÁN LẺ') {
    throw Error('Tab FM_BanIn đã tồn tại với nội dung khác. Không ghi đè tab này.');
  }
  if (!s) { s=wb.Worksheets.Add(); s.Name='FM_BanIn'; }
  const oldEnd=Math.max(35,Number(s.UsedRange.Row||1)+Number(s.UsedRange.Rows.Count||1));
  s.Range(`A1:F${Math.max(oldEnd,invoice.items.length+25)}`).ClearContents();
  put(s,1,1,'HÓA ĐƠN BÁN LẺ');
  put(s,2,1,'THÔNG TIN KHÁCH HÀNG VÀ THANH TOÁN');
  put(s,3,1,'Mã hóa đơn'); put(s,3,2,invoice.id);
  put(s,3,4,'Ngày lập'); put(s,3,5,vn(invoice.date));
  put(s,4,1,'Khách hàng'); put(s,4,2,invoice.customer);
  put(s,5,1,'Điện thoại'); put(s,5,2,invoice.phone || '—');
  put(s,6,1,'Địa chỉ / đơn vị'); put(s,6,2,invoice.address || '—');
  put(s,7,1,'Hạn thanh toán'); put(s,7,2,vn(invoice.due));
  ['STT','Hàng hóa, quy cách','Đơn vị','Số lượng','Đơn giá','Thành tiền'].forEach((v,n)=>put(s,9,n+1,v));
  invoice.items.forEach((x,n)=>{
    const row=10+n;
    [n+1,x.name,x.unit,x.qty,x.price,x.amount].forEach((v,j)=>put(s,row,j+1,v));
    s.Range(`A${row}:F${row}`).Interior.Color=n%2?C.white:C.stripe;
    s.Rows.Item(row).RowHeight=Math.min(360,Math.max(34,Math.ceil(Array.from(String(x.name||'')).length/34)*16+12));
  });
  const t=10+invoice.items.length;
  [['TỔNG TIỀN',invoice.total],['ĐÃ THU',invoice.paid],['CÒN PHẢI THU',invoice.balance]].forEach(([label,value],n)=>{
    put(s,t+n,5,label);put(s,t+n,6,value);
  });
  put(s,t+4,1,'Ghi chú'); put(s,t+4,2,invoice.note || '—');
  put(s,t+7,1,'NGƯỜI NHẬN HÀNG'); put(s,t+7,5,'NGƯỜI LẬP HÓA ĐƠN');
  widths(s,[20,38,14,15,24,23]);
  font(s.Range(`A1:F${t+8}`),11,C.ink,false);
  try {
    // Safe fixed merges: these ranges contain just one value before merging.
    for(const region of ['A1:F1','A2:F2','B3:C3','B4:C4','B5:C5','B6:D6','B7:C7',`B${t+4}:F${t+4}`])
      s.Range(region).Merge();
  } catch (_) { /* Keep separate cells when Merge is unavailable. */ }
  s.Range('A1:F1').Interior.Color=C.navy;
  font(s.Range('A1:F1'),18,C.white,true);
  s.Rows.Item(1).RowHeight=46;
  s.Range('A2:F2').Interior.Color=C.pale;
  font(s.Range('A2:F2'),10,C.teal,true);
  s.Rows.Item(2).RowHeight=28;
  s.Rows.Item(3).RowHeight=35;s.Rows.Item(4).RowHeight=Math.min(360,Math.max(39,Math.ceil(Array.from(String(invoice.customer||'')).length/46)*17+12));
  s.Rows.Item(5).RowHeight=34;s.Rows.Item(6).RowHeight=Math.min(360,Math.max(38,Math.ceil(Array.from(String(invoice.address||'')).length/65)*17+12));
  s.Rows.Item(7).RowHeight=34;
  s.Range('A9:F9').Interior.Color=C.teal;
  font(s.Range('A9:F9'),11,C.white,true);
  s.Rows.Item(9).RowHeight=34;
  s.Range(`E${t}:F${t+2}`).Interior.Color=C.pale;
  s.Range(`E${t+2}:F${t+2}`).Interior.Color=C.amber;
  s.Range(`E${t}:F${t+2}`).Font.Bold=true;
  s.Range(`E10:F${t+2}`).NumberFormat='#,##0 "đ"';
  s.Range(`A1:F${t+8}`).WrapText=true;
  s.Rows.Item(t+4).RowHeight=Math.min(360,Math.max(36,Math.ceil(Array.from(String(invoice.note||'')).length/110)*16+12));
  s.Rows.Item(t+7).RowHeight=39;
  try {s.Range(`D10:F${t+2}`).HorizontalAlignment=-4152;} catch (_) { /* xlRight. */ }
  try {s.Range(`A1:F${t+8}`).VerticalAlignment=-4108;} catch (_) { /* xlCenter. */ }
  try {const grid=s.Range(`A9:F${t-1}`);grid.Borders.LineStyle=1;grid.Borders.Color=0xe5e5e5;} catch (_) { /* Borders optional. */ }
  s.PageSetup.PrintArea=`$A$1:$F$${t+8}`;
  try { s.PageSetup.Orientation=1; s.PageSetup.PaperSize=9; s.PageSetup.Zoom=false; s.PageSetup.FitToPagesWide=1; s.PageSetup.FitToPagesTall=false; }
  catch (_) { /* Page setup differs in some WPS versions. */ }
  try {s.PageSetup.LeftMargin=34;s.PageSetup.RightMargin=34;
    s.PageSetup.TopMargin=40;s.PageSetup.BottomMargin=40;} catch (_) { /* Margins in points; keep WPS defaults on error. */ }
  try {s.PageSetup.CenterHorizontally=true;} catch (_) { /* Optional. */ }
  return s;
}
function filename(i,ext) {return OUT+`HoaDon_${String(i.id).replace(/[^A-Za-z0-9_-]/g,'_')}_${Date.now()}.${ext}`;}
function pdf(wb,i) {
  const s=printSheet(wb,i), path=filename(i,'pdf');
  s.ExportAsFixedFormat(0,path);
  return path;
}
function preview(wb,i) {const s=printSheet(wb,i);s.Activate();s.PrintPreview();}
function printStatement(wb,data) {
  let s=find(wb,'FM_BangKe');
  const title='BẢNG KÊ CÔNG NỢ KHÁCH HÀNG';
  if(s && String(s.Cells.Item(1,1).Value2 || '')!==title)
    throw Error('Tab FM_BangKe đã tồn tại với nội dung khác. Không ghi đè tab này.');
  if(!s){s=wb.Worksheets.Add();s.Name='FM_BangKe';}
  const oldEnd=Math.max(12,Number(s.UsedRange.Row||1)+Number(s.UsedRange.Rows.Count||1));
  const end=Math.max(oldEnd,12+data.invoices.length);
  s.Range(`A1:G${end}`).ClearContents();
  put(s,1,1,title);
  put(s,3,1,'Khách hàng');put(s,3,2,data.customer);
  put(s,4,1,'Điện thoại');put(s,4,2,data.phone||'—');
  put(s,5,1,'Ngày lập từ');put(s,5,2,data.from?vn(data.from):'Tất cả');
  put(s,5,4,'Đến ngày');put(s,5,5,data.to?vn(data.to):'Tất cả');
  ['Mã hóa đơn','Ngày lập','Hạn trả','Tổng tiền','Đã thu','Còn nợ','Trạng thái'].forEach((v,n)=>put(s,7,n+1,v));
  data.invoices.forEach((i,n)=>{
    const row=8+n;
    const status=i.due&&i.due<data.today?'Quá hạn':'Còn nợ';
    [i.id,vn(i.date),i.due?vn(i.due):'—',i.total,i.paid,i.balance,status].forEach((v,j)=>put(s,row,j+1,v));
    s.Range(`A${row}:G${row}`).Interior.Color=n%2?C.white:C.stripe;
    s.Rows.Item(row).RowHeight=30;
  });
  const sumRow=8+data.invoices.length;
  put(s,sumRow,5,'TỔNG CÒN NỢ');put(s,sumRow,6,data.total);
  put(s,sumRow+1,1,'Số hóa đơn đang nợ');put(s,sumRow+1,2,data.invoices.length);
  put(s,sumRow+4,1,'KHÁCH HÀNG XÁC NHẬN');put(s,sumRow+4,5,'NGƯỜI LẬP BẢNG KÊ');
  widths(s,[27,18,18,21,21,22,21]);
  font(s.Range(`A1:G${sumRow+5}`),10,C.ink,false);
  const heading=s.Range('A1:G1');heading.Interior.Color=C.navy;font(heading,16,C.white,true);
  s.Rows.Item(1).RowHeight=48;
  const tableHead=s.Range('A7:G7');tableHead.Interior.Color=C.teal;
  font(tableHead,10,C.white,true);tableHead.WrapText=true;s.Rows.Item(7).RowHeight=42;
  s.Range(`D8:F${sumRow}`).NumberFormat='#,##0 "đ"';
  const totalRange=s.Range(`E${sumRow}:F${sumRow}`);
  totalRange.Interior.Color=C.amber;font(totalRange,11,C.navy,true);
  try{s.PageSetup.PrintArea=`$A$1:$G$${sumRow+5}`;
    s.PageSetup.Orientation=1;s.PageSetup.Zoom=false;s.PageSetup.FitToPagesWide=1;s.PageSetup.FitToPagesTall=false;
  }catch(_){/* Keep a usable sheet if page layout properties are missing. */}
  return s;
}
function previewStatement(wb,data){const s=printStatement(wb,data);s.Activate();s.PrintPreview();}
function pdfStatement(wb,data){
  const s=printStatement(wb,data);
  const safe=String(data.customer||'Khach').replace(/[đĐ]/g,c=>c==='đ'?'d':'D')
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Za-z0-9_-]+/g,'_').slice(0,60)||'Khach';
  const path=OUT+`BangKe_${safe}_${Date.now()}.pdf`;
  s.ExportAsFixedFormat(0,path);
  return path;
}
function printReport(wb,data){
  let s=find(wb,'FM_BaoCao');
  const title='BÁO CÁO DOANH THU & CÔNG NỢ';
  if(s && String(s.Cells.Item(1,1).Value2||'')!==title)
    throw Error('Tab FM_BaoCao đã tồn tại với nội dung khác. Không ghi đè tab này.');
  if(!s){s=wb.Worksheets.Add();s.Name='FM_BaoCao';}
  const oldEnd=Math.max(25,Number(s.UsedRange.Row||1)+Number(s.UsedRange.Rows.Count||1));
  const end=Math.max(oldEnd,17+data.rows.length+data.top.length);
  s.Range(`A1:F${end}`).ClearContents();
  put(s,1,1,title);
  put(s,3,1,'Kỳ báo cáo');
  put(s,3,2,data.mode==='month'?'Theo tháng · '+data.year:'Theo năm · '+data.year);
  put(s,4,1,'Kỳ đang chọn');
  put(s,4,2,data.mode==='month'?'Tháng '+data.selected+'/'+data.year:'Năm '+data.selected);
  put(s,5,1,'Ngày cập nhật');put(s,5,2,vn(data.today));
  ['Tháng / Năm','Số HĐ','Doanh thu','Đã thu','Công nợ cuối kỳ','% thu'].forEach((v,n)=>put(s,7,n+1,v));
  data.rows.forEach((r,n)=>{
    const row=8+n,selected=(data.mode==='month'?r.month:r.year)===data.selected;
    [data.mode==='month'?'Tháng '+r.month:r.year,r.invoiceCount,r.revenue,r.collected,r.closingDebt,
      Math.round(r.collectRate*10)/10].forEach((v,j)=>put(s,row,j+1,v));
    s.Range(`A${row}:F${row}`).Interior.Color=selected?C.pale:n%2?C.white:C.stripe;
    s.Rows.Item(row).RowHeight=29;
  });
  const totalRow=8+data.rows.length;
  const revenue=data.rows.reduce((sum,r)=>sum+r.revenue,0);
  const collected=data.rows.reduce((sum,r)=>sum+r.collected,0);
  [ 'TỔNG CỘNG',data.rows.reduce((sum,r)=>sum+r.invoiceCount,0),revenue,collected,
    data.rows.length?data.rows[data.rows.length-1].closingDebt:0,
    revenue?Math.round(collected/revenue*1000)/10:0].forEach((v,j)=>put(s,totalRow,j+1,v));
  put(s,totalRow+2,1,'KHÁCH CÒN NỢ NHIỀU NHẤT ĐẾN CUỐI KỲ');
  ['Khách hàng','Điện thoại','Công nợ'].forEach((v,n)=>put(s,totalRow+3,n+1,v));
  data.top.forEach((g,n)=>{put(s,totalRow+4+n,1,g.customer);put(s,totalRow+4+n,2,g.phone||'—');put(s,totalRow+4+n,3,g.balance);});
  const foot=totalRow+5+data.top.length;
  put(s,foot,1,'Doanh thu: hóa đơn lập trong kỳ. Đã thu: phiếu thu trong kỳ, kể cả hóa đơn kỳ trước.');
  put(s,foot+1,1,'Công nợ cuối kỳ: tổng hóa đơn đến cuối kỳ trừ tổng đã thu đến cuối kỳ.');
  widths(s,[26,16,23,23,25,17]);
  font(s.Range(`A1:F${foot+2}`),10,C.ink,false);
  s.Range('A1:F1').Interior.Color=C.navy;font(s.Range('A1:F1'),16,C.white,true);
  s.Rows.Item(1).RowHeight=46;
  s.Range('A7:F7').Interior.Color=C.teal;font(s.Range('A7:F7'),10,C.white,true);
  s.Range('A7:F7').WrapText=true;s.Rows.Item(7).RowHeight=40;
  s.Range(`C8:E${totalRow}`).NumberFormat='#,##0 "đ"';
  s.Range(`F8:F${totalRow}`).NumberFormat='0.0"%"';
  s.Range(`A${totalRow}:F${totalRow}`).Interior.Color=C.amber;
  font(s.Range(`A${totalRow}:F${totalRow}`),11,C.navy,true);
  s.Range(`A${totalRow+2}:F${totalRow+2}`).Interior.Color=C.navy;
  font(s.Range(`A${totalRow+2}:F${totalRow+2}`),10,C.white,true);
  if(data.top.length)s.Range(`C${totalRow+4}:C${totalRow+3+data.top.length}`).NumberFormat='#,##0 "đ"';
  try{
    s.PageSetup.PrintArea=`$A$1:$F$${foot+2}`;
    s.PageSetup.PaperSize=9; // xlPaperA4
    s.PageSetup.Orientation=2; // Landscape
    s.PageSetup.Zoom=false;s.PageSetup.FitToPagesWide=1;s.PageSetup.FitToPagesTall=false;
  }catch(_){/* Keep the report sheet if a WPS page-setting API is unavailable. */}
  return s;
}
function previewReport(wb,data){const s=printReport(wb,data);s.Activate();s.PrintPreview();}
function pdfReport(wb,data){
  const s=printReport(wb,data);
  const period=String(data.period||'Ky').replace(/[^A-Za-z0-9_-]/g,'_');
  const path=OUT+`BaoCao_${period}_${Date.now()}.pdf`;
  s.ExportAsFixedFormat(0,path);
  return path;
}
function png(application,i) {
  const canvas=document.createElement('canvas'),width=1240,left=72,right=1168;
  const c=canvas.getContext('2d');
  function wrap(value,max,size){
    c.font=size+'px Arial';let lines=[],line='';
    for(const word of String(value==null?'—':value).split(/\s+/)) {
      if(!word)continue;
      if(c.measureText(word).width>max) {
        if(line){lines.push(line);line='';}
        let part='';for(const ch of word){if(part&&c.measureText(part+ch).width>max){lines.push(part);part=ch;}else part+=ch;}
        line=part;continue;
      }
      const next=line?line+' '+word:word;
      if(line&&c.measureText(next).width>max){lines.push(line);line=word;}else line=next;
    }
    if(line)lines.push(line);return lines.length?lines:['—'];
  }
  const meta=[['Mã hóa đơn',i.id],['Ngày lập',vn(i.date)],['Khách hàng',i.customer],['Điện thoại',i.phone||'—'],['Địa chỉ / đơn vị',i.address||'—'],['Hạn thanh toán',vn(i.due)]];
  const metaLines=meta.map(([,value])=>wrap(value,830,21));
  const metaHeight=metaLines.reduce((sum,lines)=>sum+Math.max(40,lines.length*29+10),0);
  const itemLines=i.items.map(x=>wrap(x.name,465,20));
  const itemHeights=itemLines.map(lines=>Math.max(52,lines.length*29+17));
  const noteLines=wrap(i.note||'—',880,20);
  const tableTop=202+metaHeight+20;
  const tableEnd=tableTop+52+itemHeights.reduce((sum,h)=>sum+h,0);
  const totalTop=tableEnd+32, noteTop=totalTop+165;
  const signTop=noteTop+noteLines.length*28+95;
  canvas.width=width;canvas.height=Math.max(900,signTop+90);
  c.fillStyle='#fff';c.fillRect(0,0,width,canvas.height);
  c.fillStyle='#183050';c.fillRect(0,0,width,122);
  c.fillStyle='#fff';c.font='bold 36px Arial';c.fillText('HÓA ĐƠN BÁN LẺ',left,76);
  c.fillStyle='#196270';c.font='bold 21px Arial';c.fillText('THÔNG TIN KHÁCH HÀNG VÀ THANH TOÁN',left,159);
  let y=202;
  meta.forEach(([label],n)=>{
    c.fillStyle='#536477';c.font='bold 20px Arial';c.fillText(label+':',left,y);
    c.fillStyle='#24364d';c.font='21px Arial';
    metaLines[n].forEach((line,j)=>c.fillText(line,320,y+j*29));
    y+=Math.max(40,metaLines[n].length*29+10);
  });
  y=tableTop;
  c.fillStyle='#196270';c.fillRect(left,y,right-left,52);
  c.fillStyle='#fff';c.font='bold 18px Arial';
  [['STT',86],['Hàng hóa, quy cách',141],['ĐVT',643],['SL',739],['Đơn giá',865],['Thành tiền',1042]].forEach(([v,x])=>c.fillText(v,x,y+34));
  y+=52;
  i.items.forEach((item,n)=>{
    const h=itemHeights[n];c.fillStyle=n%2?'#fff':'#f3f7f9';c.fillRect(left,y,right-left,h);
    c.fillStyle='#24364d';c.font='20px Arial';c.fillText(String(n+1),86,y+32);
    itemLines[n].forEach((line,j)=>c.fillText(line,141,y+31+j*29));
    const rightText=(value,x)=>{const t=String(value);c.fillText(t,x-c.measureText(t).width,y+32);};
    c.fillText(String(item.unit||'—'),643,y+32);
    rightText(fmt(item.qty),823);rightText(fmt(item.price),987);rightText(fmt(item.amount),1158);
    y+=h;
  });
  c.fillStyle='#e5e7eb';c.fillRect(left,y,right-left,2);
  y=totalTop;
  [['Tổng tiền',i.total],['Đã thu',i.paid],['Còn phải thu',i.balance]].forEach(([label,value],n)=>{
    c.fillStyle=n===2?'#991b1b':'#183050';c.font='bold 23px Arial';
    c.fillText(label,760,y+n*46);
    const valueText=fmt(value)+' đ';c.fillText(valueText,right-c.measureText(valueText).width,y+n*46);
  });
  c.fillStyle='#24364d';c.font='bold 20px Arial';c.fillText('Ghi chú:',left,noteTop);
  c.font='20px Arial';noteLines.forEach((line,n)=>c.fillText(line,240,noteTop+n*28));
  c.font='bold 21px Arial';c.fillText('NGƯỜI NHẬN HÀNG',left,signTop);c.fillText('NGƯỜI LẬP HÓA ĐƠN',860,signTop);
  const data=canvas.toDataURL('image/png').split(',')[1];
  const path=filename(i,'png');
  if (!application.FileSystem || !application.FileSystem.writeAsBinaryString) throw Error('Bản WPS này chưa hỗ trợ lưu ảnh PNG trực tiếp.');
  application.FileSystem.writeAsBinaryString(path,atob(data));
  return path;
}

root.InvoiceView={formatAndRefresh,formatAll,pdf,png,preview,printStatement,previewStatement,pdfStatement,printReport,previewReport,pdfReport,vn};
})(window);
