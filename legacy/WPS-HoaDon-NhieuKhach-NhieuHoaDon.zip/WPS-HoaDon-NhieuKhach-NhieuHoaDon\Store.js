/* Runs inside a WPS JS add-in task pane. Values are stored in the active workbook. */
(function (root) {
'use strict';
const TABLES = {
  FM_HoaDon: ['Mã HĐ','Ngày','Khách hàng','Điện thoại','Địa chỉ / đơn vị','Hạn trả','Tổng tiền','Ghi chú','Chi tiết JSON','Mã yêu cầu'],
  FM_ThuTien: ['Mã phiếu','Mã HĐ','Ngày thu','Số tiền','Phương thức','Ghi chú','Mã yêu cầu']
};
function app() { if (!root.Application || !Application.ActiveWorkbook) throw Error('Hãy mở một tệp bảng tính trong WPS trước.'); return Application; }
function workbook() { return app().ActiveWorkbook; }
function findSheet(name) { const sheets=workbook().Worksheets; for(let n=1;n<=sheets.Count;n++){const s=sheets.Item(n);if(s.Name===name)return s;} return null; }
function lastRow(s) {
  // The sheet is formatted by columns; UsedRange can include thousands of empty styled rows.
  // Column A is the committed record ID and is written last by append().
  try {
    const row=Number(s.Range('A1048576').End(-4162).Row); // xlUp
    if(Number.isSafeInteger(row)&&row>=1&&row<=1048576)return row;
  } catch (_) { /* Fallback for WPS builds without Range.End. */ }
  const u=s.UsedRange, end=Math.max(1,Number(u.Row||1)+Number(u.Rows.Count||1)-1);
  if(end>50000)throw Error('Không xác định được dòng dữ liệu cuối. Hãy kiểm tra cột A và phiên bản WPS trước khi lưu thêm.');
  for(let row=end;row>1;row--)if(raw(s,row,1)!=null&&raw(s,row,1)!=='')return row;
  return 1;
}
function raw(s,row,col) { return s.Cells.Item(row,col).Value2; }
function write(s,row,col,value) { s.Cells.Item(row,col).Value2=value; }
function text(v,max) { const t=String(v==null?'':v).trim();if(t.length>max)throw Error('Nội dung quá dài.');return t; }
function cell(v) { return /^[=+\-@]/.test(v)?"'"+v:v; }
function uncell(v) { return String(v==null?'':v).replace(/^'(?=[=+\-@])/, ''); }
function money(v) { const n=Number(v);if(!Number.isSafeInteger(n)||n<0||n>1e12)throw Error('Số tiền phải là số nguyên từ 0 đến 1.000 tỷ.');return n; }
function date(v) { if(!/^\d{4}-\d{2}-\d{2}$/.test(v||''))throw Error('Ngày không hợp lệ.');const d=new Date(v+'T00:00:00Z');if(isNaN(d)||d.toISOString().slice(0,10)!==v)throw Error('Ngày không hợp lệ.');return v; }
function isoDate(v) {if(v==null||v==='')return '';if(typeof v==='number'){const d=new Date(Math.round(v-25569)*86400000);return isNaN(d)?'':d.toISOString().slice(0,10);}if(v instanceof Date)return v.toISOString().slice(0,10);const s=String(v).trim();if(/^\d{4}-\d{2}-\d{2}$/.test(s))return s;const m=/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);if(m){const first=Number(m[1]),second=Number(m[2]),day=first>12?first:second,month=first>12?second:first;return m[3]+'-'+String(month).padStart(2,'0')+'-'+String(day).padStart(2,'0');}return s;}
function checkHeaders(s,name) { const expected=TABLES[name];const found=expected.map((_,c)=>raw(s,1,c+1));
  if(expected.some((v,c)=>found[c]!==v))throw Error('Tab '+name+' có tiêu đề khác cấu trúc. Chưa sửa dữ liệu; hãy kiểm tra hàng 1.'); }
function sheets() { const result={}; for(const name of Object.keys(TABLES)){const s=findSheet(name);if(!s)throw Error('Chưa có tab '+name+'. Bấm “Khởi tạo dữ liệu” trong bảng thử trước.');checkHeaders(s,name);result[name]=s;} return result; }
function init() { app();for(const name of Object.keys(TABLES)){let s=findSheet(name);if(!s){s=workbook().Worksheets.Add();s.Name=name;TABLES[name].forEach((h,c)=>write(s,1,c+1,h));}else{const vals=TABLES[name].map((_,c)=>raw(s,1,c+1));if(vals.every(v=>v==null||v===''))TABLES[name].forEach((h,c)=>write(s,1,c+1,h));else checkHeaders(s,name);}}
 return present(state()); }
function rows(s,name) {const out=[];for(let r=2;r<=lastRow(s);r++){const a=TABLES[name].map((_,c)=>raw(s,r,c+1));if(a[0]!=null&&a[0]!=='')out.push({row:r,values:a});}return out;}
function revision(a) {return JSON.stringify(a.slice(1,9));}
function invoiceValues(d){const customer=text(d.customer,200);if(!customer)throw Error('Nhập tên khách hàng.');const issued=date(d.date),due=d.due?date(d.due):'';if(due&&due<issued)throw Error('Hạn trả trước ngày lập.');if(!Array.isArray(d.items)||!d.items.length||d.items.length>100)throw Error('Cần 1–100 mặt hàng.');const items=d.items.map(i=>{const name=text(i.name,200),unit=text(i.unit,40),qty=Number(i.qty),price=money(i.price);if(!name||!Number.isFinite(qty)||qty<=0||qty>1e6)throw Error('Mặt hàng / số lượng không hợp lệ.');return {name,unit,qty,price,amount:money(Math.round(qty*price))};});const total=money(items.reduce((sum,i)=>sum+i.amount,0));if(!total)throw Error('Tổng hóa đơn phải lớn hơn 0.');return [issued,cell(customer),cell(text(d.phone,40)),cell(text(d.address,500)),due,total,cell(text(d.note,1000)),JSON.stringify(items)];}
function unique(prefix){return prefix+'-'+Date.now().toString(36).toUpperCase()+'-'+Math.random().toString(36).slice(2,9).toUpperCase();}
function append(s,vals,textColumns=[]) {
  let r=lastRow(s)+1;
  // A failed earlier write may leave data in B:J with a blank A; never overwrite it.
  while(r<=1048576&&vals.some((_,c)=>c>0&&raw(s,r,c+1)!=null&&raw(s,r,c+1)!==''))r++;
  if(r>1048576)throw Error('Bảng dữ liệu đã hết dòng. Hãy tạo workbook mới sau khi sao lưu.');
  for(const col of textColumns)try{s.Cells.Item(r,col).NumberFormat='@';}catch(_){}
  for(let c=1;c<vals.length;c++)write(s,r,c+1,vals[c]);
  write(s,r,1,vals[0]);return r;
}
function state() {
  const sh=sheets(),payRows=rows(sh.FM_ThuTien,'FM_ThuTien'),invRows=rows(sh.FM_HoaDon,'FM_HoaDon');
  const paidByInvoice=new Map();
  const payments=payRows.map(x=>{
    const p={id:x.values[0],invoice:x.values[1],date:isoDate(x.values[2]),amount:Number(x.values[3]),method:uncell(x.values[4]),note:uncell(x.values[5])};
    if(!Number.isSafeInteger(p.amount)||p.amount<=0)throw Error('Số tiền phiếu thu '+p.id+' không hợp lệ.');
    paidByInvoice.set(p.invoice,(paidByInvoice.get(p.invoice)||0)+p.amount);
    return p;
  });
  const seen=new Set();
  const invoices=invRows.map(x=>{
    const a=x.values,id=String(a[0]);
    if(seen.has(id))throw Error('Trùng mã hóa đơn '+id+' trong FM_HoaDon. Chưa sửa dữ liệu; hãy kiểm tra cột A.');
    seen.add(id);
    let items;try{items=JSON.parse(a[8]);}catch(_){throw Error('Chi tiết JSON của hóa đơn '+id+' không hợp lệ.');}
    const paid=paidByInvoice.get(id)||0,total=Number(a[6]);
    if(!Number.isSafeInteger(total)||!Number.isSafeInteger(paid)||paid>total)throw Error('Dữ liệu tiền của hóa đơn '+id+' không hợp lệ.');
    return{id,date:isoDate(a[1]),customer:uncell(a[2]),phone:uncell(a[3]),address:uncell(a[4]),due:isoDate(a[5]),total,note:uncell(a[7]),items,paid,balance:total-paid,revision:revision(a)};
  });
  for(const id of paidByInvoice.keys())if(!seen.has(String(id)))throw Error('Phiếu thu tham chiếu hóa đơn '+id+' không tồn tại. Chưa sửa dữ liệu.');
  const t=new Date(),today=[t.getFullYear(),String(t.getMonth()+1).padStart(2,'0'),String(t.getDate()).padStart(2,'0')].join('-');
  return{invoices,payments,today};
}
function present(result) {if(root.InvoiceView){try{root.InvoiceView.formatAndRefresh(workbook(),result);}catch(e){result.viewError=String(e.message||e);}}return result;}
function editable(id,rev){const sh=sheets(),x=rows(sh.FM_HoaDon,'FM_HoaDon').find(r=>r.values[0]===id);if(!x)throw Error('Hóa đơn không còn tồn tại.');if(rows(sh.FM_ThuTien,'FM_ThuTien').some(r=>r.values[1]===id))throw Error('Đã có phiếu thu, không thể sửa hoặc xóa hóa đơn.');if(revision(x.values)!==rev)throw Error('Hóa đơn đã đổi. Tải lại trước khi sửa.');return x;}
const api={
 init,
 getState(){return present(state());},
 saveInvoice(d){const sh=sheets(),request=text(d.request,100);if(!request)throw Error('Thiếu mã yêu cầu.');const existing=rows(sh.FM_HoaDon,'FM_HoaDon'),duplicate=existing.find(x=>x.values[9]===request);if(duplicate)return{id:duplicate.values[0],state:present(state())};const vals=invoiceValues(d),used=new Set(existing.map(x=>String(x.values[0])));let id;do{id=unique('HD')}while(used.has(id));append(sh.FM_HoaDon,[id,...vals,request],[4]);return{id,state:present(state())};},
 updateInvoice(d){const x=editable(text(d.id,100),d.revision),vals=invoiceValues(d),sh=sheets();try{sh.FM_HoaDon.Cells.Item(x.row,4).NumberFormat='@';}catch(_){}try{vals.forEach((v,c)=>write(sh.FM_HoaDon,x.row,c+2,v));}catch(e){x.values.slice(1,9).forEach((v,c)=>write(sh.FM_HoaDon,x.row,c+2,v));throw e;}return{id:d.id,state:present(state())};},
 deleteInvoice(d){const x=editable(text(d.id,100),d.revision);sheets().FM_HoaDon.Rows.Item(x.row).Delete();return present(state());},
 savePayment(d){const sh=sheets(),request=text(d.request,100);if(!request)throw Error('Thiếu mã yêu cầu.');const existing=rows(sh.FM_ThuTien,'FM_ThuTien');if(existing.some(x=>x.values[6]===request))return present(state());const inv=state().invoices.find(i=>i.id===d.invoice);if(!inv)throw Error('Không tìm thấy hóa đơn.');const amount=money(d.amount),day=date(d.date);if(amount<=0||amount>inv.balance)throw Error('Số thu phải lớn hơn 0 và không vượt dư nợ.');if(day<inv.date)throw Error('Ngày thu trước ngày lập hóa đơn.');const method=text(d.method,50);if(!['Tiền mặt','Chuyển khoản','Khác'].includes(method))throw Error('Phương thức không hợp lệ.');const used=new Set(existing.map(x=>String(x.values[0])));let id;do{id=unique('PT')}while(used.has(id));append(sh.FM_ThuTien,[id,inv.id,day,amount,cell(method),cell(text(d.note,1000)),request]);return present(state());}
};
root.InvoiceStore=api;
})(window);
