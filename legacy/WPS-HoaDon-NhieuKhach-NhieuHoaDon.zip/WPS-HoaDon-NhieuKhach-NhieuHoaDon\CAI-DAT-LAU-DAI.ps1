﻿# Chạy một lần trong PowerShell của chính tài khoản dùng WPS. Có thể chạy lại để sửa cấu hình.
$ErrorActionPreference = 'Stop'
$root = 'G:\Xe_Nang'
$source = Join-Path $root 'ma-nguon'
$node = Join-Path $root 'tools\node-v22.22.3-win-x64\node.exe'
$server = Join-Path $source 'server.js'
foreach ($file in @($node, $server, (Join-Path $source 'App.html'), (Join-Path $source 'ribbon.xml'))) {
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Thiếu tệp: $file. Hãy giải nén mã nguồn vào $source trước." }
}

$configDir = Join-Path $env:APPDATA 'kingsoft\wps\jsaddons'
New-Item -ItemType Directory -Force -Path $configDir | Out-Null
$config = Join-Path $configDir 'publish.xml'
if (Test-Path -LiteralPath $config) {
    Copy-Item -LiteralPath $config -Destination ($config + '.backup-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $xml = New-Object System.Xml.XmlDocument
    $xml.Load($config)
} else {
    $xml = New-Object System.Xml.XmlDocument
    $xml.LoadXml('<?xml version="1.0" encoding="utf-8"?><jsplugins/>')
}
if ($xml.DocumentElement.LocalName -ne 'jsplugins') { throw "Cấu trúc $config khác dự kiến; bản sao đã được giữ lại." }
$plugin = $xml.SelectSingleNode('/jsplugins/jspluginonline[@name="XeNangHoaDon" and @type="et"]')
if ($null -eq $plugin) {
    $plugin = $xml.CreateElement('jspluginonline')
    [void]$xml.DocumentElement.AppendChild($plugin)
}
$plugin.SetAttribute('name', 'XeNangHoaDon')
$plugin.SetAttribute('type', 'et')
$plugin.SetAttribute('url', 'http://127.0.0.1:38931/')
$plugin.SetAttribute('enable', 'true')
$xml.Save($config)

$taskName = 'XeNang-HoaDon-WPS'
$action = New-ScheduledTaskAction -Execute $node -Argument ('"' + $server + '"') -WorkingDirectory $source
$trigger = New-ScheduledTaskTrigger -AtLogOn -User ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
$settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Seconds 0) -StartWhenAvailable -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
$principal = New-ScheduledTaskPrincipal -UserId ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Description 'Máy chủ cục bộ của công cụ hóa đơn WPS' -Force | Out-Null

try {
    $response = Invoke-WebRequest -Uri 'http://127.0.0.1:38931/ribbon.xml' -UseBasicParsing -TimeoutSec 3
} catch {
    Start-ScheduledTask -TaskName $taskName
    Start-Sleep -Seconds 2
    $response = Invoke-WebRequest -Uri 'http://127.0.0.1:38931/ribbon.xml' -UseBasicParsing -TimeoutSec 5
}
if ($response.StatusCode -ne 200 -or $response.Content -notmatch 'OnAddInLoad') {
    throw 'Máy chủ còn đang phục vụ bản cũ. Kiểm tra tiến trình Node cũ trên cổng 38931, rồi khởi động lại tác vụ.'
}
Write-Host "Cấu hình WPS: $config"
Write-Host "Tác vụ: $taskName - $((Get-ScheduledTask -TaskName $taskName).State)"
Write-Host 'Máy chủ trả về HTTP 200. Đóng hoàn toàn WPS rồi mở lại để WPS nạp add-in và tự mở bảng điều khiển.'
