/* WPS Sheets add-in entry. No Google services or external server calls. */
var invoicePane;
function GetUrlPath() { return window.location.href.replace(/\/[^/]*$/, ''); }
function OpenInvoiceTool(quiet) {
  try {
    if (!invoicePane) invoicePane = Application.CreateTaskPane(GetUrlPath() + '/App.html?v=20261013-1521', 'Hóa đơn & Công nợ');
    if (!invoicePane) throw Error('WPS không tạo được bảng điều khiển. Kiểm tra bản WPS có hỗ trợ JS add-in.');
    invoicePane.Visible = true;
  } catch (e) { if (quiet !== true) Application.alert(String(e.message || e)); }
}
// WPS invokes this once when it loads the ribbon; reopen the pane for each session.
function OnAddInLoad() {
  window.setTimeout(function () {
    try { OpenInvoiceTool(true); }
    catch (_) { /* The ribbon button remains available if the pane cannot open yet. */ }
  }, 350);
}
