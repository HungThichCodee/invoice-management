# Hóa đơn & Công nợ cho WPS Sheets

Mã nguồn add-in WPS cục bộ. Giao diện tiếng Việt dùng Arial; tạo hóa đơn, sửa/xóa khi chưa thu, thu tiền, xem chi tiết, xem trước/in, xuất PDF và PNG. Dữ liệu và các trang trình bày nằm trong chính workbook, còn ảnh và PDF lưu tại `G:\Xe_Nang\du-lieu`. Không cần Google Sheets.

Giao diện có bốn tab **Tạo hóa đơn / Hóa đơn – Công nợ / Khách hàng / Báo cáo**. Tab Khách hàng gom theo tên viết thường và điện thoại, lọc theo ngày lập, theo dõi các lần thu và xuất bảng kê. Tab Báo cáo xem số liệu theo tháng hoặc năm, đã thu, công nợ cuối kỳ và xuất PDF; bấm một tháng để xem từng hóa đơn ngay dưới dòng tháng (hoặc bấm năm để chuyển sang danh sách tháng). Không có biểu đồ. Nút **Định dạng bảng** tự dãn cột hai sheet dữ liệu; các ô ngày dùng lịch tiếng Việt và lưu dạng `ngày/tháng/năm` trên giao diện. `FM_BanIn` đã tạo sẽ tự cập nhật số đã thu và còn nợ khi thu tiền cho hóa đơn đang hiển thị.

**Chưa xác nhận trên WPS 12.1.0.28485 của bạn:** bản in/PDF/PNG, lệnh tự mở task pane và việc tự chạy theo lịch đăng nhập cần thử trên bản sao workbook. Các bài thử tự động chỉ kiểm tra logic với đối tượng WPS giả lập.

## Cập nhật bản đang chạy, giữ dữ liệu

1. Sao chép tệp `.xlsx` hiện có sang một tên dự phòng, ví dụ `HoaDon-sao-luu.xlsx`. Giữ tệp gốc an toàn.
2. Dừng cửa sổ PowerShell đang chạy `server.js` bằng **Ctrl+C**. Giải nén ZIP mới vào `G:\Xe_Nang\ma-nguon`, ghi đè mã cũ. Kiểm tra có cùng thư mục: `index.html`, `main.js`, `ribbon.xml`, `App.html`, `Store.js`, `View.js`, `DatePicker.js`, `Report.js`, `server.js`. Bảng `files` của `server.js` phải có `/DatePicker.js` và `/Report.js`.
3. Chạy lại máy chủ (chỉ cho lần thử đầu):

   ```powershell
   & 'G:\Xe_Nang\tools\node-v22.22.3-win-x64\node.exe' 'G:\Xe_Nang\ma-nguon\server.js'
   ```

4. Đóng hẳn WPS và mở lại bản sao workbook. Trong bảng điều khiển bấm **Làm mới** hoặc **Khởi tạo dữ liệu**. Tool sẽ định dạng hai tab dữ liệu, thêm `FM_TongQuan` và giữ nguyên hai tab cũ `FM_HoaDon`, `FM_ThuTien`. Nếu đã có `FM_TongQuan` với nội dung khác, tool sẽ dừng phần trình bày thay vì ghi đè.
5. Tạo hóa đơn thử bằng lịch, thử tab **Khách hàng**, **Báo cáo**, nút **Định dạng bảng**, **Xem trước**, **PDF**, **Ảnh PNG**, rồi kiểm tra tệp mới trong `G:\Xe_Nang\du-lieu`. Bấm Ctrl+S trong WPS sau khi cập nhật bảng.

## Giữ add-in sau khi tắt/mở WPS hoặc khởi động lại máy

Sau khi giải nén bản mới vào `G:\Xe_Nang\ma-nguon`, chạy **một lần** trong PowerShell của tài khoản đang dùng WPS:

```powershell
& 'G:\Xe_Nang\ma-nguon\CAI-DAT-LAU-DAI.ps1'
```

Nếu PowerShell chỉ chặn tệp tải về, có thể chạy đúng một phiên như sau (không đổi chính sách toàn hệ thống):

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'G:\Xe_Nang\ma-nguon\CAI-DAT-LAU-DAI.ps1'
```

Script sao lưu rồi cập nhật mục add-in trong `%APPDATA%\kingsoft\wps\jsaddons\publish.xml`, đăng ký tác vụ chạy Node ở lúc đăng nhập, kiểm tra `ribbon.xml` phải trả HTTP 200 và chứa `OnAddInLoad`. Nó không đụng đến workbook. Đóng hoàn toàn WPS và mở lại; ribbon **Hóa đơn & Công nợ** phải có nút **Mở quản lý hóa đơn**, đồng thời giao diện sẽ thử tự mở khi WPS nạp add-in. Nếu WPS không tự mở pane, nhấn nút trên ribbon. Máy chủ chỉ tự chạy sau khi đăng nhập Windows của cùng tài khoản; tắt/mở riêng WPS sẽ dùng máy chủ đang chạy.

Nếu bản mã cũ vẫn được phục vụ trên cổng 38931, dừng tiến trình Node cũ (không dừng WPS), chạy lại tác vụ `XeNang-HoaDon-WPS` rồi đóng/mở WPS. Kiểm tra bằng:

```powershell
Get-ScheduledTask -TaskName 'XeNang-HoaDon-WPS' | Get-ScheduledTaskInfo
(Invoke-WebRequest 'http://127.0.0.1:38931/ribbon.xml' -UseBasicParsing).StatusCode
Get-Content "$env:APPDATA\kingsoft\wps\jsaddons\publish.xml"
```

G: phải sẵn sàng khi đăng nhập. Nếu chỉ thiếu ribbon mà HTTP đã là 200, cần kiểm tra WPS có đọc `publish.xml` của đúng tài khoản đang chạy hay không.

## Dữ liệu và xuất tệp

### Nhiều hóa đơn và nhiều khách trong một workbook

- Mở đúng tệp WPS muốn dùng làm sổ dữ liệu. Mỗi lần bấm **Lưu hóa đơn** tạo một mã và một dòng mới trong `FM_HoaDon`; không tạo workbook hay sheet riêng cho từng khách. `FM_ThuTien` lưu các lần thu theo **mã hóa đơn**, nên mỗi hóa đơn có thể có nhiều lần thu độc lập.
- Để lập hóa đơn thứ hai, thứ ba cho cùng khách, gõ tên/số điện thoại vào **Chọn khách đã có**, bấm đúng khách; tên, số điện thoại và địa chỉ gần nhất sẽ được điền vào form. Bấm **Lưu & tạo tiếp cho khách này** nếu cần nhập liên tiếp nhiều hóa đơn. Mỗi hóa đơn mới có mặt hàng, ngày, hạn trả và số tiền riêng.
- Khách hàng trên tab Công nợ được nhóm theo cặp **tên đã cắt khoảng trắng và chuyển chữ thường + số điện thoại đã cắt khoảng trắng**. Người trùng tên nhưng khác số điện thoại là hai nhóm. Nếu sửa tên hoặc số điện thoại trong hóa đơn, hóa đơn đó có thể chuyển sang nhóm khác; hãy chọn khách cũ để tránh tách công nợ. Giao diện cảnh báo khi gặp tên hoặc điện thoại giống khách có sẵn nhưng thông tin còn lại khác.
- Dòng dữ liệu đã có được giữ nguyên. Tool đọc dòng cuối bằng mã ở cột A, không dựa vào các dòng trống đã được định dạng trong WPS; nếu thấy dòng ghi dở thì bỏ qua thay vì ghi đè. Trùng mã hóa đơn hoặc phiếu thu tham chiếu mã không tồn tại sẽ báo lỗi để bạn kiểm tra, không tự sửa dữ liệu.
- Nếu bạn chuyển sang workbook khác khi đang mở bảng điều khiển, bấm **Làm mới** trước khi lưu hoặc xuất. Công cụ sẽ chặn thao tác ghi khi giao diện đang hiển thị dữ liệu của một tệp khác. Sau khi lưu hóa đơn/phiếu thu, bấm **Ctrl+S** trong WPS để ghi các thay đổi của workbook xuống đĩa.

- Dữ liệu chính nằm trong workbook `.xlsx` mà bạn mở. `FM_TongQuan` là bản tổng hợp được cập nhật từ hai tab dữ liệu. `FM_BanIn` in hóa đơn, `FM_BangKe` in bảng kê khách hàng, `FM_BaoCao` in báo cáo; không xóa các tab này khi còn dùng tool. Các trang này có tiêu đề khóa tại A1 và từ chối ghi đè nếu gặp tab cùng tên với nội dung khác.
- Các cột kỹ thuật chứa JSON/mã yêu cầu được ẩn, không bị xóa. Không tự đổi tên `FM_HoaDon`, `FM_ThuTien` hoặc sửa tiêu đề hàng 1. Công cụ chặn bảng có tiêu đề khác để tránh ghi đè.
- Cột điện thoại của hóa đơn mới được đặt dạng văn bản để giữ số 0 đầu. Nếu một số điện thoại trong bản cũ đã bị WPS tự đổi thành số và mất số 0, định dạng mới không thể tự khôi phục chữ số đã mất; hãy kiểm tra và sửa hóa đơn chưa thu trên bản sao trước.
- PDF dùng `Worksheet.ExportAsFixedFormat` của WPS; PNG dùng canvas Arial rồi lưu bằng `FileSystem.writeAsBinaryString`. Nếu một hàm không có trong bản WPS của bạn, giao diện sẽ báo lỗi rõ, dữ liệu hóa đơn vẫn nằm trong workbook.
- Tệp PDF/PNG được đặt tên theo mã hóa đơn và thời điểm xuất, tránh đè bản cũ. Cần có thư mục `G:\Xe_Nang\du-lieu` và quyền ghi ở đó.
- Ô ngày chọn bằng lịch trong `DatePicker.js`, hiển thị `ngày/tháng/năm`, ví dụ `13/10/2026`; dữ liệu lưu vẫn là `yyyy-mm-dd`. `Report.js` chỉ tính toán từ dữ liệu đã tải, không đọc workbook mỗi lần đổi kỳ. Báo cáo tính doanh thu theo ngày lập hóa đơn, đã thu theo ngày phiếu thu và công nợ cuối kỳ theo lũy kế. Giao diện của tool bằng tiếng Việt, nhưng phần menu/hộp thoại hệ thống của WPS hoặc Windows dùng ngôn ngữ cài đặt của máy.
- Sau mỗi đợt nhập và khi thêm trang tổng quan hoặc trang in, bấm Ctrl+S. Không mở cùng một workbook trong hai cửa sổ để sửa đồng thời.

## Dữ liệu thật

Ứng dụng không sinh hóa đơn/phiếu thu giả. Mọi số liệu trên giao diện đều đọc từ `FM_HoaDon` và `FM_ThuTien` của workbook WPS hiện mở. Các file `test-*` dành riêng cho máy lập trình; **không** có trong gói cài đặt và không được server phục vụ. Nếu trước đây đã nhập thử các dòng như khách `j` hoặc `f`, đó là dữ liệu trong workbook của bạn; cần chọn đúng các hóa đơn để xóa bằng giao diện (chỉ hóa đơn chưa có phiếu thu). Hãy sao lưu workbook rồi xác nhận các mã trước khi xóa; công cụ không tự xóa bất kỳ dòng nào dựa vào tên khách.
